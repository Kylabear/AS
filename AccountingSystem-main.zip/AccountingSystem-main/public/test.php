<?php
echo "PHP is working!";
phpinfo();
?>
