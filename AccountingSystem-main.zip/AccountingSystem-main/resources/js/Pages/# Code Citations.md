# Code Citations

## License: MIT
https://github.com/cucumber/cucumber-ruby/blob/d9d6f380c77b79c3670fa8f1d620d7b57f42b3ae/release-notes/5.0.0.md

```
:**
```
```


## License: MIT
https://github.com/cucumber/cucumber-ruby/blob/d9d6f380c77b79c3670fa8f1d620d7b57f42b3ae/features/docs/cli/publish_banner.feature

```
:**
```
```


## License: unknown
https://github.com/stan-alam/NodeJS/blob/81c5863420ee6e3c2a6efaefec37bfab54a15624/coreNode/README.md

```
:**
```
```


## License: unknown
https://github.com/priyankarmitra/test-automation-project/blob/ada141e94b248c792a5208a4114cfb908d322da8/README.md

```
:**
```
```


## License: MIT
https://github.com/cucumber/cucumber-ruby/blob/d9d6f380c77b79c3670fa8f1d620d7b57f42b3ae/release-notes/5.0.0.md

```
:**
```
┌─────────────
```


## License: MIT
https://github.com/cucumber/cucumber-ruby/blob/d9d6f380c77b79c3670fa8f1d620d7b57f42b3ae/features/docs/cli/publish_banner.feature

```
:**
```
┌─────────────
```


## License: unknown
https://github.com/stan-alam/NodeJS/blob/81c5863420ee6e3c2a6efaefec37bfab54a15624/coreNode/README.md

```
:**
```
┌─────────────
```


## License: unknown
https://github.com/priyankarmitra/test-automation-project/blob/ada141e94b248c792a5208a4114cfb908d322da8/README.md

```
:**
```
┌─────────────
```


## License: MIT
https://github.com/cucumber/cucumber-ruby/blob/d9d6f380c77b79c3670fa8f1d620d7b57f42b3ae/release-notes/5.0.0.md

```
:**
```
┌─────────────────────────────────
```


## License: MIT
https://github.com/cucumber/cucumber-ruby/blob/d9d6f380c77b79c3670fa8f1d620d7b57f42b3ae/features/docs/cli/publish_banner.feature

```
:**
```
┌─────────────────────────────────
```


## License: unknown
https://github.com/stan-alam/NodeJS/blob/81c5863420ee6e3c2a6efaefec37bfab54a15624/coreNode/README.md

```
:**
```
┌─────────────────────────────────
```


## License: unknown
https://github.com/priyankarmitra/test-automation-project/blob/ada141e94b248c792a5208a4114cfb908d322da8/README.md

```
:**
```
┌─────────────────────────────────
```


## License: MIT
https://github.com/cucumber/cucumber-ruby/blob/d9d6f380c77b79c3670fa8f1d620d7b57f42b3ae/release-notes/5.0.0.md

```
:**
```
┌─────────────────────────────────────────────────────
```


## License: MIT
https://github.com/cucumber/cucumber-ruby/blob/d9d6f380c77b79c3670fa8f1d620d7b57f42b3ae/features/docs/cli/publish_banner.feature

```
:**
```
┌─────────────────────────────────────────────────────
```


## License: unknown
https://github.com/stan-alam/NodeJS/blob/81c5863420ee6e3c2a6efaefec37bfab54a15624/coreNode/README.md

```
:**
```
┌─────────────────────────────────────────────────────
```


## License: unknown
https://github.com/priyankarmitra/test-automation-project/blob/ada141e94b248c792a5208a4114cfb908d322da8/README.md

```
:**
```
┌─────────────────────────────────────────────────────
```


## License: MIT
https://github.com/cucumber/cucumber-ruby/blob/d9d6f380c77b79c3670fa8f1d620d7b57f42b3ae/release-notes/5.0.0.md

```
:**
```
┌──────────────────────────────────────────────────────
```


## License: MIT
https://github.com/cucumber/cucumber-ruby/blob/d9d6f380c77b79c3670fa8f1d620d7b57f42b3ae/features/docs/cli/publish_banner.feature

```
:**
```
┌──────────────────────────────────────────────────────
```


## License: unknown
https://github.com/stan-alam/NodeJS/blob/81c5863420ee6e3c2a6efaefec37bfab54a15624/coreNode/README.md

```
:**
```
┌──────────────────────────────────────────────────────
```


## License: unknown
https://github.com/priyankarmitra/test-automation-project/blob/ada141e94b248c792a5208a4114cfb908d322da8/README.md

```
:**
```
┌──────────────────────────────────────────────────────
```


## License: MIT
https://github.com/cucumber/cucumber-ruby/blob/d9d6f380c77b79c3670fa8f1d620d7b57f42b3ae/features/docs/cli/publish_banner.feature

```
└
```


## License: MIT
https://github.com/cucumber/cucumber-ruby/blob/d9d6f380c77b79c3670fa8f1d620d7b57f42b3ae/features/docs/cli/publish_banner.feature

```
└─────────────────
```


## License: MIT
https://github.com/drigols/studies/blob/a337076da251e87e926ccfd593c5a0f86912e4d1/modules/python-codes/modules/typer/README.md

```
└─────────────────
```


## License: MIT
https://github.com/cucumber/cucumber-ruby/blob/d9d6f380c77b79c3670fa8f1d620d7b57f42b3ae/features/docs/cli/publish_banner.feature

```
└─────────────────────────────────────
```


## License: MIT
https://github.com/drigols/studies/blob/a337076da251e87e926ccfd593c5a0f86912e4d1/modules/python-codes/modules/typer/README.md

```
└─────────────────────────────────────
```


## License: MIT
https://github.com/cucumber/cucumber-ruby/blob/d9d6f380c77b79c3670fa8f1d620d7b57f42b3ae/features/docs/cli/publish_banner.feature

```
└─────────────────────────────────────────────────────────
```


## License: MIT
https://github.com/drigols/studies/blob/a337076da251e87e926ccfd593c5a0f86912e4d1/modules/python-codes/modules/typer/README.md

```
└─────────────────────────────────────────────────────────
```


## License: MIT
https://github.com/cucumber/cucumber-ruby/blob/d9d6f380c77b79c3670fa8f1d620d7b57f42b3ae/features/docs/cli/publish_banner.feature

```
└─────────────────────────────────────────────────────────────┘
```
```


## License: MIT
https://github.com/drigols/studies/blob/a337076da251e87e926ccfd593c5a0f86912e4d1/modules/python-codes/modules/typer/README.md

```
└─────────────────────────────────────────────────────────────┘
```
```


## License: MIT
https://github.com/cucumber/cucumber-ruby/blob/d9d6f380c77b79c3670fa8f1d620d7b57f42b3ae/features/docs/cli/publish_banner.feature

```
└─────────────────────────────────────────────────────────────┘
```

**
```


## License: MIT
https://github.com/drigols/studies/blob/a337076da251e87e926ccfd593c5a0f86912e4d1/modules/python-codes/modules/typer/README.md

```
└─────────────────────────────────────────────────────────────┘
```

**
```


## License: MIT
https://github.com/cucumber/cucumber-ruby/blob/d9d6f380c77b79c3670fa8f1d620d7b57f42b3ae/features/docs/cli/publish_banner.feature

```
└─────────────────────────────────────────────────────────────┘
```

**What
```


## License: MIT
https://github.com/drigols/studies/blob/a337076da251e87e926ccfd593c5a0f86912e4d1/modules/python-codes/modules/typer/README.md

```
└─────────────────────────────────────────────────────────────┘
```

**What
```

